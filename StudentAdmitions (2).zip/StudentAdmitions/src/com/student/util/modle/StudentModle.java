package com.student.modle;

import javax.persistence.*;

@Entity
public class StudentModle{
    @Id
    @GeneratedValue(strategy=GenerationType.AUTO)
	private String name;
    private String faculty;
	private String department;
	private String id;
	 

	

	public StudentModle(String name, String faculty, String department, String id) {
		super();
		this.name = name;
		this.faculty = faculty;
		this.department = department;
		this.id = id;
	}


	public StudentModle() {
		// TODO Auto-generated constructor stub
	}


	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getFaculty() {
		return faculty;
	}

	public void setFaculty(String faculty) {
		this.faculty = faculty;
	}

	public String getDepartment() {
		return department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}



	

	
	
	
	
	
}
