package com.student.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import com.student.modle.StudentModle;
import com.student.util.HibernateUtil;

public class StudentDao {

	public String registerStudent(StudentModle theStudents) {
		
		try {
			Session ss=HibernateUtil.getSessionFactory().openSession();
			Transaction tr= ss.beginTransaction();
			ss.save(theStudents);
			if(theStudents != null) {
				return "Data Saved";
			}else {
				return "Data Not Saved";
			}
		}catch(Exception ex) {
			ex.printStackTrace();
		}
		return null;
		
	}
	
public String updateStudent(StudentModle theStudents) {
		
		try {
			Session ss=HibernateUtil.getSessionFactory().openSession();
			Transaction tr= ss.beginTransaction();
			ss.update(theStudents);
			if(theStudents != null) {
				return "Data Updated";
			}else {
				return "Data Not Updated";
			}
		}catch(Exception ex) {
			ex.printStackTrace();
		}
		return null;
		
	}
public String deleteStudent(String id) {
	
	try {
		Session ss=HibernateUtil.getSessionFactory().openSession();
		Transaction tr= ss.beginTransaction();
		ss.delete(id);
		if(id != null) {
			return "Data Deleted";
		}else {
			return "Data Not Deleted";
		}
	}catch(Exception ex) {
		ex.printStackTrace();
	}
	return null;
	
}

 public List<StudentModle> allStudents(){
	try {
		 Session ss=HibernateUtil.getSessionFactory().openSession();
		 List<StudentModle> theStudents=ss.createQuery("select stud from StudentModle stud").list();
		 if(theStudents !=null) {
			 return theStudents;
		 }else {
			 return null;
		 }
			
	}catch(Exception ex) {
		ex.printStackTrace();
	}
	return null;
 }
 
 public StudentModle login(String username, int userId) {
	    StudentModle loggedInStudent = null;
	    try {
	        Session session = HibernateUtil.getSessionFactory().openSession();
	        Transaction transaction = session.beginTransaction();


	        Query query = session.createQuery("from StudentModel where username = :username and userId = :userId");
	        query.setParameter("username", username);
	        query.setParameter("userId", userId);
	        
	        List<StudentModle> resultList = query.list();

	        if (!resultList.isEmpty()) {
	            loggedInStudent = resultList.get(0); // Assuming there's only one student with the given credentials
	        }

	        transaction.commit();
	    } catch (Exception ex) {
	        ex.printStackTrace();
	    }
	    return loggedInStudent;
}
 
 public String resetPassword(String username) {
	    try {
	        Session session = HibernateUtil.getSessionFactory().openSession();
	        Transaction transaction = session.beginTransaction();

	        // Retrieve the student by username
	        Query query = session.createQuery("from StudentModel where username = :username");
	        query.setParameter("username", username);
	        StudentModle student =  (StudentModle) query.uniqueResult();

	        if (student != null) {
	           
	            student.setId(username);
	            session.update(student);
	            transaction.commit();
	            return "Password updated successfully";
	        } else {
	            return "Username not found";
	        }
	    } catch (Exception ex) {
	        ex.printStackTrace();
	        return "Error resetting password";
	    }
	}

 }
