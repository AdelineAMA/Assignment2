package com.student.Controler;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.student.dao.StudentDao;


@WebServlet("/ResetPasswordServlet")
public class ResetPasswordServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    
    public ResetPasswordServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

   
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
       
        request.getRequestDispatcher("/ResetPassword.html").forward(request, response);
    }

    
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        
        String username = request.getParameter("username");
     
        StudentDao  dao =new StudentDao();
        String result = dao.resetPassword(username);

        // Forwarding the request to a result page
        request.setAttribute("result", result);
        request.getRequestDispatcher("/ResetPassword.html").forward(request, response);
    }

    
    private String updateStudentPassword(String username, String newPassword) {
        try {
            
        	StudentDao  dao =new StudentDao();
            String updateResult = dao.resetPassword(username);
            return updateResult;
        } catch (Exception ex) {
            ex.printStackTrace();
            return "Error resetting password";
        }
    }
}
