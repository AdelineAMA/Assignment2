package com.student.Controler;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import com.student.dao.StudentDao;
import com.student.modle.StudentModle;

@WebServlet("/DeleteServlet")
public class DeleteServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
      
        response.sendRedirect("Login.html");
    }

   
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int studentId = Integer.parseInt(request.getParameter("studentId"));

        // Call service method to delete the student record
        
        StudentDao dao =new StudentDao();
        StudentModle mode= new StudentModle();
        mode.setId(studentId);
        String delet= dao.deleteStudent(id);
        

       
        if (delet !=null) {
            response.sendRedirect("Login.html");
        } else {
            response.sendRedirect("");
        }
    }
}
