package com.student.Controler;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
javax.servlet.annotation.WebServlet;
import com.student.dao.StudentDao;
import com.student.modle.StudentModle;


@WebServlet("/register")
public class RegisterStudentServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	
		
		String name=req.getParameter("name");
		String faculty=req.getParameter("faculty");
		String department=req.getParameter("department");
		String id=req.getParameter("id");
		StudentModle theStudents= new StudentModle(name,faculty,department,id);
		theStudents.setName(name);
		theStudents.setFaculty(faculty);
		theStudents.setDepartment(department);
		theStudents.setId(id);		
		StudentDao dao= new StudentDao();
		String data =dao.registerStudent(theStudents);
		if(data !=null) {
			System.out.println(data);
		}else {
			System.out.println(data);
		}
	}
	
	
   

}
