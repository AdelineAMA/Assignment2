package com.student.Controler;

public @interface WebServlet {

	String value();

}
